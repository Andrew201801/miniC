package com.zhushoumao.bianyi.util;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import com.zhushoumao.bianyi.pojo.HashMap2;

import sun.launcher.resources.launcher;
/**
 * @author PuHaiyang
 * @createTime 2016骞�6鏈�11鏃� 涓婂崍9:12:53
 * @email 761396462@qq.com
 * @function 瀛楃宸ュ叿绫�
 *
 */
public class TextUtil {
    /**
     * (3)B->aA,=Follow(B)
     *
     * @param nvSet
     * @param itemCharStr
     * @param a
     * @param expressionMap
     * @return
     */
    public static boolean containsbA(TreeSet<String> nvSet, String i, String a,
                                     HashMap2 expressionMap) {
        String aStr = a;
        String[] itemCharStr=i.split(" ");
        String lastStr = itemCharStr[itemCharStr.length-1];
        if (lastStr.equals(aStr)) {
            return true;
        }
        return false;
        
    }

    /**
     * 褰㈠aBb,b=绌�
     *
     * @param nvSet
     * @param itemCharStr
     * @param a
     * @param expressionMap
     * @return
     */
    public static boolean containsbAbIsNull(TreeSet<String> nvSet, String itemCharStr, String a,HashMap2 expressionMap) {
        String aStr = a;
        if (containsAB(nvSet, itemCharStr, a)) {
            String alastChar = getAlastChar(itemCharStr, a);
//            System.out.println("----------------+++++++++++++++++++--" + expressionMap.toString());
            ArrayList<String> arrayList = expressionMap.get(alastChar);
            if (arrayList.contains("ε")) {
                System.out.println(alastChar + "  contains('ε')" + aStr);
                return true;
            }
        }
        return false;

    }

    /**
     * 鏄惁鍖呭惈杩欑鐨勫瓧绗︿覆<Br>
     * (2)Ab,=First(b)-蔚,鐩存帴娣诲姞缁堢粨绗�
     *
     * @param itemCharStr
     * @param a
     * @return
     */
    public static boolean containsAb(TreeSet<String> ntSet, String i, String a) {
        String aStr = a;
        String[] itemCharStr=i.split(" ");
        for(int x=0;x<itemCharStr.length;x++){
        	if(itemCharStr[x].equals(a)){
        		int aIndex = x;
                ArrayList<String>findStr =new ArrayList<>();
                try {
                    findStr.add(itemCharStr[x+1]);
                    findStr.add(itemCharStr[x+2]);
                } catch (Exception e) {
                    return false;
                }
                if (ntSet.contains(findStr.get(0))) {
                    return true;
                } else {
                    return false;
                }
        	}
        }
        return false;
    }

    /**
     * 鏄惁鍖呭惈杩欑鐨勫瓧绗︿覆<Br>
     * (2).2Ab,=First(b)-蔚
     *
     * @param itemCharStr
     * @param a
     * @return
     */
    public static boolean containsAB(TreeSet<String> nvSet, String i, String a) {
    	String aStr = a;
        String[] itemCharStr=i.split(" ");
        for(int x=0;x<itemCharStr.length;x++){
        	if(itemCharStr[x].equals(a)){
        		int aIndex = x;
                ArrayList<String>findStr =new ArrayList<>();
                try {
                    findStr.add(itemCharStr[x+1]);
                    findStr.add(itemCharStr[x+2]);
                } catch (Exception e) {
                    return false;
                }
                if (nvSet.contains(findStr.get(0))) {
                    return true;
                } else {
                    return false;
                }
        	}
        }
        return false;
    }

    /**
     * 鑾峰彇A鍚庣殑瀛楃
     *
     * @param itemCharStr
     * @param a
     * @return
     */
    public static String getAlastChar(String i, String a) {
        String aStr = a;
        String[] itemCharStr=i.split(" ");
        for(int x=0;x<itemCharStr.length;x++){
        	if(itemCharStr[x].equals(a)){
        		int aIndex = x;
                ArrayList<String>findStr =new ArrayList<>();
                try {
                    findStr.add(itemCharStr[x+1]);
                    findStr.add(itemCharStr[x+2]);
                } catch (Exception e) {
                    return null;
                }
                return findStr.get(0);
        	}
        }
        return null;
    }

    /**
     * 鏄惁涓何靛紑濮嬬殑
     *
     * @param selectExp
     * @return
     */
    public static boolean isEmptyStart(String selectExp) {
    	String charAt = selectExp.split(" ")[0];
        if (selectExp.equals("ε")) {
            return true;
        }
        return false;
    }

    /**
     * 鏄惁鏄粓缁撶寮�濮嬬殑
     *
     * @param ntSet
     * @param selectExp
     * @return
     */
    public static boolean isNtStart(TreeSet<String> ntSet, String selectExp) {
    	String charAt = selectExp.split(" ")[0];
        if (ntSet.contains(charAt)) {
            return true;
        }
        return false;
    }

    /**
     * 鏄惁鏄潪缁堢粨绗﹀紑濮嬬殑
     *
     * @param nvSet
     * @param selectExp
     * @return
     */
    public static boolean isNvStart(TreeSet<String> nvSet, String selectExp) {
    	
    	String charAt = selectExp.split(" ")[0];
        if (nvSet.contains(charAt)) {
//        	 System.out.println("有哦了");
            return true;
        }
        return false;
    }

    /**
     * 鏌ユ壘浜х敓寮�
     *
     * @param selectMap
     * @param peek
     *            褰撳墠Nv
     * @param charAt
     *            褰撳墠瀛楃
     * @return
     */
    public static String findUseExp(TreeMap<String, HashMap<String, TreeSet<String>>> selectMap, String peek,
                                    String charAt) {
        try {
//        	if(peek.equals("Block")){
//        		System.out.println();
//        		System.out.println(charAt);
//        		System.out.println(selectMap.get(peek));
//        		System.out.println();
//        	}
            HashMap<String, TreeSet<String>> hashMap = selectMap.get(peek);
            Set<String> keySet = hashMap.keySet();
            for (String useExp : keySet) {
                TreeSet<String> treeSet = hashMap.get(useExp);
                if (treeSet.contains(charAt)) {
                    return useExp;
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }
}