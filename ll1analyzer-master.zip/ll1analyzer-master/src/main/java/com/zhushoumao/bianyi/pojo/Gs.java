package com.zhushoumao.bianyi.pojo;
import java.io.Serializable;  
import java.util.ArrayList;  
import java.util.HashMap;  
import java.util.Iterator;  
import java.util.Set;  
import java.util.TreeMap;  
import java.util.TreeSet;

import com.sun.org.apache.regexp.internal.recompile;
import com.zhushoumao.bianyi.util.TextUtil;  
import com.zhushoumao.bianyi.pojo.HashMap2;
/** 
 * @author PuHaiyang 
 * @createTime 2016年6月10日 下午7:46:33 
 * @email 761396462@qq.com 
 * @function LL(1)文法 
 * 
 */  






public class Gs implements Serializable {  
  
    /** 
     *  
     */  
    private static final long serialVersionUID = 1L;  
  
    public Gs() {  
        super();  
        gsArray = new ArrayList<String>();  
        nvSet = new TreeSet<String>();  
        ntSet = new TreeSet<String>();  
        firstMap = new HashMap<String, TreeSet<String>>();  
        followMap = new HashMap<String, TreeSet<String>>();  
        selectMap = new TreeMap<String, HashMap<String, TreeSet<String>>>();  
    }  
  
    private String[][] analyzeTable;  
  
    /** 
     * Select集合 
     */  
    private TreeMap<String, HashMap<String, TreeSet<String>>> selectMap;  
    /** 
     * LL（1）文法产生集合 
     */  
    private ArrayList<String> gsArray;  
    /** 
     * 表达式集合 
     */  
    private HashMap2 expressionMap;  
    /** 
     * 开始符 
     */  
    private String s;  
    /** 
     * Vn非终结符集合 
     */  
    private TreeSet<String> nvSet;  
    /** 
     * Vt终结符集合 
     */  
    private TreeSet<String> ntSet;  
    /** 
     * First集合 
     */  
    private HashMap<String, TreeSet<String>> firstMap;  
    /** 
     * Follow集合 
     */  
    private HashMap<String, TreeSet<String>> followMap;  
  
    public String[][] getAnalyzeTable() {  
        return analyzeTable;  
    }  
  
    public void setAnalyzeTable(String[][] analyzeTable) {  
        this.analyzeTable = analyzeTable;  
    }  
  
    public TreeMap<String, HashMap<String, TreeSet<String>>> getSelectMap() {  
        return selectMap;  
    }  
  
    public void setSelectMap(TreeMap<Character, HashMap<String, TreeSet<Character>>> selectMap) {  
        this.selectMap = selectMap;  
    }  
  
    public HashMap<String, TreeSet<String>> getFirstMap() {  
        return firstMap;  
    }  
  
    public void setFirstMap(HashMap<String, TreeSet<Character>> firstMap) {  
        this.firstMap = firstMap;  
    }  
  
    public HashMap<String, TreeSet<String>> getFollowMap() {  
        return followMap;  
    }  
  
    public void setFollowMap(HashMap<Character, TreeSet<Character>> followMap) {  
        this.followMap = followMap;  
    }  
  
    public HashMap2 getExpressionMap() {  
        return expressionMap;  
    }  
  
    public void setExpressionMap(HashMap<Character, ArrayList<String>> expressionMap) {  
        this.expressionMap = expressionMap;  
    }  
  
    public ArrayList<String> getGsArray() {  
        return gsArray;  
    }  
  
    public void setGsArray(ArrayList<String> gsArray) {  
        this.gsArray = gsArray;  
    }  
  
    public String getS() {  
        return s;  
    }  
  
    public void setS(String s) {  
        this.s = s;  
    }  
  
    public TreeSet<String> getNvSet() {  
        return nvSet;  
    }  
  
    public void setNvSet(TreeSet<Character> nvSet) {  
        this.nvSet = nvSet;  
    }  
  
    public TreeSet<String> getNtSet() {  
        return ntSet;  
    }  
  
    public void setNtSet(TreeSet<Character> ntSet) {  
        this.ntSet = ntSet;  
    }  
  
    /** 
     * 获取非终结符集与终结符集 
     *  
     * @param gsArray 
     * @param nvSet 
     * @param ntSet 
     */  
    public void getNvNt() {  
        for (String gsItem : gsArray) {  
            String[] nvNtItem = gsItem.split("->");  
            String stringItemStr = nvNtItem[0];  
//            char charItem = charItemStr.charAt(0);  
            // nv在左边  
            nvSet.add(stringItemStr);  
        }  
        for (String gsItem : gsArray) {  
            String[] nvNtItem = gsItem.split("->");  
            // nt在右边  
            String[] nvItemStr = nvNtItem[1].split(" "); 
            // 遍历每一个字  
            for (int i = 0; i < nvItemStr.length; i++) {  
                String stringItem = nvItemStr[i];  
                if (!nvSet.contains(stringItem)) {  
                    ntSet.add(stringItem);  
                }  
            }  
        }  
    }  
  
    /** 
     * 初始化表达式集合 
     */  
    public void initExpressionMaps() {  
        expressionMap = new HashMap2();  
        for (String gsItem : gsArray) {  
            String[] nvNtItem = gsItem.split("->");  
            String charItemStr = nvNtItem[0];  
            String charItemRightStr = nvNtItem[1];  
//            char charItem = charItemStr.charAt(0);  
            if (!expressionMap.containsKey(charItemStr)) {   
            	ArrayList<String> expArr = new ArrayList<String>();  
                expArr.add(charItemRightStr); 
                expressionMap.put(charItemStr, expArr);
            } else {  
                ArrayList<String> expArr = expressionMap.get(charItemStr);  
                expArr.add(charItemRightStr);  
                expressionMap.put(charItemStr, expArr);  
            }  
        }  
    }  
    
    
//    public void initExpressionMaps() {  
//        expressionMap = new HashMap<Character, ArrayList<String>>();  
//        for (String gsItem : gsArray) {  
//            String[] nvNtItem = gsItem.split("->");  
//            String charItemStr = nvNtItem[0];  
//            String charItemRightStr = nvNtItem[1];  
//            char charItem = charItemStr.charAt(0);  
//            if (!expressionMap.containsKey(charItem)) {  
//                ArrayList<String> expArr = new ArrayList<String>();  
//                expArr.add(charItemRightStr);  
//                expressionMap.put(charItem, expArr);  
//            } else {  
//                ArrayList<String> expArr = expressionMap.get(charItem);  
//                expArr.add(charItemRightStr);  
//                expressionMap.put(charItem, expArr);  
//            }  
//        }  
//    }
//  
    /** 
     * 获取First集 
     */  
    public void getFirst() {  
        // 遍历所有Nv,求出它们的First集合  
        Iterator<String> iterator = nvSet.iterator();  
        while (iterator.hasNext()) {  
            String stringItem = iterator.next();  
            ArrayList<String> arrayList = expressionMap.get(stringItem);  
//            for(int i=0;i<expressionMap.size();)
//            System.out.println(expressionMap);
            for (String itemStr : arrayList) {  
                boolean shouldBreak = false;  
                // Y1Y2Y3...Yk
                String[] stringstr=itemStr.split(" ");
                for (int i = 0; i < stringstr.length; i++) {  
                    String itemitemChar = stringstr[i];  
                    TreeSet<String> itemSet = firstMap.get(stringItem);  
                    if (null == itemSet) {  
                        itemSet = new TreeSet<String>();  
                    }  
                    shouldBreak = calcFirst(itemSet,stringItem, itemitemChar);  
                    if (shouldBreak) {  
                        break;  
                    }  
                }  
            }  
        }  
    }  
  
    /** 
     * 计算First函数 
     *  
     * @param itemSet 
     * @param charItem 
     * @param itemitemChar 
     * @return 
     */  
    private boolean calcFirst(TreeSet<String> itemSet, String charItem, String itemitemChar) {  
        // get ago  
        // TreeSet<Character> itemSet = new TreeSet<Character>();  
        // 将它的每一位和Nt判断下  
        // 是终结符或空串,就停止，并将它加到FirstMap中  
        if (itemitemChar.equals("ε")|| ntSet.contains(itemitemChar)) {  
            itemSet.add(itemitemChar);  
            firstMap.put(charItem, itemSet);  
            // break;  
            return true;  
        } else if (nvSet.contains(itemitemChar)) {// 这一位是一个非终结符  
            ArrayList<String> arrayList = expressionMap.get(itemitemChar);  
            for (int i = 0; i < arrayList.size(); i++) {  
                String string = arrayList.get(i);  
                String tempChar = string.split(" ")[0];  
                calcFirst(itemSet, charItem, tempChar);  
            }  
        }  
        return true;  
    }  
  
    /** 
     * 获取Follow集合 
     */  
    public void getFollow() {  
        for (String tempKey : nvSet) {  
            TreeSet<String> tempSet = new TreeSet<String>();  
            followMap.put(tempKey, tempSet);  
        }  
        // 遍历所有Nv,求出它们的First集合  
        Iterator<String> iterator = nvSet.descendingIterator();  
        // nvSet.descendingIterator();  
  
        while (iterator.hasNext()) {  
            String charItem = iterator.next();  
//            System.out.println("Item:" + charItem);  
            ArrayList<String> keySet = expressionMap.getLeft();  
            for (String keyCharItem : keySet) {  
                ArrayList<String> charItemArray = expressionMap.get(keyCharItem);  
                for (String itemCharStr : charItemArray) {  
//                    System.out.println(keyCharItem + "->" + itemCharStr)  
                    TreeSet<String> itemSet = followMap.get(charItem);  
                    calcFollow(charItem, charItem, keyCharItem, itemCharStr, itemSet);  
                } 
                
            }  
//            System.out.println();
        }  
    }  
  
    /** 
     * 计算Follow集 
     *  
     * @param putCharItem 
     *            正在查询item 
     * @param charItem 
     *            待找item 
     * @param keyCharItem 
     *            节点名 
     * @param itemCharStr 
     *            符号集 
     * @param itemSet 
     *            结果集合 
     */  
    private void calcFollow(String putCharItem, String charItem, String keyCharItem, String itemCharStr,  
            TreeSet<String> itemSet) {  
        ///////  
        // （1）A是S（开始符)，加入#  
        if (charItem.equals(s)) {  
            itemSet.add("#");  
//            System.out.println("---------------find S:" + charItem + "   ={#}+Follow(E)");  
            followMap.put(putCharItem, itemSet);  
            // return;  
        }  
//         (2)Ab,=First(b)-ε,直接添加终结符  
        if (TextUtil.containsAb(ntSet, itemCharStr, charItem)) {  
            String alastChar = TextUtil.getAlastChar(itemCharStr, charItem);  
//            System.out.println("---------------find Ab:" + itemCharStr + "    " + charItem + "   =" + alastChar);  
            itemSet.add(alastChar);  
            followMap.put(putCharItem, itemSet);  
            // return;  
        }  
//         (2).2AB,=First(B)-ε,=First(B)-ε，添加first集合  
        if (TextUtil.containsAB(nvSet, itemCharStr, charItem)) {  
            String alastChar = TextUtil.getAlastChar(itemCharStr, charItem);  
//            System.out.println(  
//                    "---------------find AB:" + itemCharStr + "    " + charItem + "   =First(" + alastChar + ")");  
            TreeSet<String> treeSet = firstMap.get(alastChar);  
            itemSet.addAll(treeSet);  
            if (treeSet.contains("ε")) {  
                itemSet.add("#");  
            }  
            itemSet.remove("ε");  
            followMap.put(putCharItem, itemSet);  
            ///////////////////////  
            if (TextUtil.containsbAbIsNull(nvSet, itemCharStr, charItem, expressionMap)) {  
                String tempChar = TextUtil.getAlastChar(itemCharStr, charItem);  
                System.out.println("tempChar:" + tempChar + "  key" + keyCharItem);  
                if (!keyCharItem.equals(charItem)) {  
//                    System.out.println("---------------find tempChar bA: " + "tempChar:" + tempChar + keyCharItem  
//                            + "   " + itemCharStr + "    " + charItem + "   =Follow(" + keyCharItem + ")");  
                   ArrayList<String> keySet = expressionMap.getLeft();  
                    for (String keyCharItems : keySet) {  
                        ArrayList<String> charItemArray = expressionMap.get(keyCharItems);  
                        for (String itemCharStrs : charItemArray) {  
                            calcFollow(putCharItem, keyCharItem, keyCharItems, itemCharStrs, itemSet);  
                        }  
                    }  
                }  
            }  
        }  
//        // (3)B->aA,=Follow(B),添加followB  
        if (TextUtil.containsbA(nvSet, itemCharStr, charItem, expressionMap)) {  
            if (!keyCharItem.equals(charItem)) {  
//                System.out.println("---------------find bA: " + keyCharItem + "   " + itemCharStr + "    " + charItem  
//                        + "   =Follow(" + keyCharItem + ")");  
                ArrayList<String> keySet = expressionMap.getLeft();  
                for (String keyCharItems : keySet) {  
                    ArrayList<String> charItemArray = expressionMap.get(keyCharItems);  
                    for (String itemCharStrs : charItemArray) {  
                        calcFollow(putCharItem, keyCharItem, keyCharItems, itemCharStrs, itemSet);  
                    }  
                }  
            }  
        }  
    }  
  
    /** 
     * 获取Select集合 
     */  
    public void getSelect() {  
        // 遍历每一个表达式  
        // HashMap<Character, HashMap<String, TreeSet<Character>>>  
        ArrayList<String> keySet = expressionMap.getLeft();  
        for (String selectKey : keySet) {  
            ArrayList<String> arrayList = expressionMap.get(selectKey);  
            // 每一个表达式  
            HashMap<String, TreeSet<String>> selectItemMap = new HashMap<String, TreeSet<String>>();  
            for (String selectExp : arrayList) {  
                /** 
                 * 存放select结果的集合 
                 */  
//            	System.out.println("new selection");
//            	System.out.println(selectExp);
                TreeSet<String> selectSet = new TreeSet<String>();  
                // set里存放的数据分3种情况,由selectExp决定  
                // 1.A->ε,=follow(A)  
                if (TextUtil.isEmptyStart(selectExp)) {  
                    selectSet = followMap.get(selectKey);  
                    selectSet.remove("ε");  
                    selectItemMap.put(selectExp, selectSet);  
                }  
                // 2.Nt开始,=Nt  
                // <br>终结符开始  
                if (TextUtil.isNtStart(ntSet, selectExp)) {  
//                	System.out.println();
//                	System.out.println("isNtStart");
//                	System.out.println();
                    selectSet.add(selectExp.split(" ")[0]);  
                    selectSet.remove("ε");  
                    selectItemMap.put(selectExp, selectSet);  
                }  
                // 3.Nv开始，=first(Nv)  
                if (TextUtil.isNvStart(nvSet, selectExp)) {  
//                	System.out.println();
//                	System.out.println("B");
//                	System.out.println();
                    selectSet = firstMap.get(selectKey);  
                    selectSet.remove("ε");  
                    selectItemMap.put(selectExp, selectSet);  
                }  
                selectMap.put(selectKey, selectItemMap);  
            }  
        }  
    }  
  
    /** 
     * 生成预测分析表 
     */  
    public void genAnalyzeTable() throws Exception {  
        Object[] ntArray = ntSet.toArray();  
        Object[] nvArray = nvSet.toArray();  
        // 预测分析表初始化  
        analyzeTable = new String[nvArray.length + 1][ntArray.length + 1];  
  
        // 输出一个占位符  
        System.out.print("Nv/Nt" + "\t\t");  
        analyzeTable[0][0] = "Nv/Nt";  
        // 初始化首行  
        for (int i = 0; i < ntArray.length; i++) {  
            if (ntArray[i].equals('ε')) {  
                ntArray[i] = '#';  
            }  
            System.out.print(ntArray[i] + "\t\t");  
            analyzeTable[0][i + 1] = ntArray[i] + "";  
        }  
  
        System.out.println("");  
        for (int i = 0; i < nvArray.length; i++) {  
            // 首列初始化  
            System.out.print(nvArray[i] + "\t\t");  
            analyzeTable[i + 1][0] = nvArray[i] + "";  
            for (int j = 0; j < ntArray.length; j++) {  
                String findUseExp = TextUtil.findUseExp(selectMap, Character.valueOf((Character) nvArray[i]),  
                        Character.valueOf((Character) ntArray[j]));  
                if (null == findUseExp) {  
                    System.out.print("\t\t");  
                    analyzeTable[i + 1][j + 1] = "";  
                } else {  
                    System.out.print(nvArray[i] + "->" + findUseExp + "\t\t");  
                    analyzeTable[i + 1][j + 1] = nvArray[i] + "->" + findUseExp;  
                }  
            }  
            System.out.println();  
        }  
    }  
}
